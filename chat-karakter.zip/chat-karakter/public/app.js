(function () {
  const app = document.getElementById('app');
  let S = null, tab = 'chat', busy = false, draft = '';
  const GENDERS = [['perempuan', 'Perempuan'], ['laki-laki', 'Laki-laki'], ['lainnya', 'Lainnya']];

  function h(tag, props, ...kids) {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(props || {})) {
      if (k === 'class') e.className = v;
      else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
      else if (v !== false && v != null) e.setAttribute(k, v);
    }
    for (const c of kids.flat()) if (c != null) e.append(c);
    return e;
  }

  async function api(path, opts = {}) {
    const r = await fetch('/api/' + path, {
      method: opts.method || 'GET',
      headers: { 'content-type': 'application/json' },
      body: opts.body ? JSON.stringify(opts.body) : undefined,
    });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) { const e = new Error(d.error || 'Terjadi kesalahan.'); e.status = r.status; throw e; }
    return d;
  }

  function toast(msg) {
    const t = h('div', { class: 'toast', role: 'status' }, msg);
    document.body.append(t);
    setTimeout(() => t.remove(), 3500);
  }
  const mount = (...n) => app.replaceChildren(...n);

  function loadScript(src) {
    return new Promise((res, rej) => {
      const s = h('script', { src, async: '' });
      s.onload = res; s.onerror = rej;
      document.head.append(s);
    });
  }

  async function boot() {
    try { S = await api('state'); route(); }
    catch (e) {
      if (e.status === 401) viewLogin();
      else mount(h('main', { class: 'gate' }, h('p', {}, 'Tidak bisa terhubung ke server. Muat ulang halaman.')));
    }
  }

  function route() {
    if (!S.character) viewCharacter();
    else if (!S.user.username) viewProfile();
    else viewApp();
  }

  /* ---------- Login ---------- */
  async function viewLogin() {
    const slot = h('div', { style: 'min-height:44px' });
    mount(h('main', { class: 'gate' },
      h('h1', {}, 'Ruang Cerita'),
      h('p', { class: 'lead' }, 'Ngobrol dengan karakter buatanmu sendiri. Masuk dulu untuk mulai.'),
      slot));
    try {
      const { clientId } = await api('config');
      if (!window.google) await loadScript('https://accounts.google.com/gsi/client');
      google.accounts.id.initialize({
        client_id: clientId,
        callback: async (r) => {
          try { await api('login', { method: 'POST', body: { credential: r.credential } }); await boot(); }
          catch (e) { toast(e.message); }
        },
      });
      google.accounts.id.renderButton(slot, { theme: 'outline', size: 'large', text: 'continue_with', shape: 'pill' });
    } catch (e) {
      slot.textContent = 'Tombol Google gagal dimuat. Periksa koneksi, lalu muat ulang.';
    }
  }

  /* ---------- Form karakter & profil ---------- */
  function field(label, control) { return h('label', { class: 'field' }, label, control); }
  function genderPicker(name) {
    return h('div', { class: 'seg', role: 'radiogroup' },
      GENDERS.map(([v, l]) => h('label', {}, h('input', { type: 'radio', name, value: v, required: '' }), h('span', {}, l))));
  }

  function viewCharacter() {
    const f = h('form', {
      class: 'card form',
      onsubmit: async (e) => {
        e.preventDefault();
        const fd = new FormData(f);
        try {
          await api('character', { method: 'POST', body: { name: fd.get('name'), gender: fd.get('gender'), traits: fd.get('traits') } });
          await boot();
        } catch (er) { toast(er.message); }
      },
    },
      h('div', {}, h('h1', {}, 'Buat karakter'), h('p', { class: 'lead' }, 'Siapa teman ngobrolmu?')),
      field('Nama karakter', h('input', { name: 'name', required: '', maxlength: '40', autocomplete: 'off' })),
      h('div', { class: 'field' }, 'Jenis kelamin karakter', genderPicker('gender')),
      field('Karakter yang kamu suka', h('textarea', { name: 'traits', required: '', maxlength: '300', rows: '3', placeholder: 'Contoh: ceria, perhatian, suka bercanda, suka kopi' })),
      h('button', { class: 'btn', type: 'submit' }, 'Lanjut'));
    mount(h('main', { class: 'gate' }, f));
  }

  function viewProfile() {
    const f = h('form', {
      class: 'card form',
      onsubmit: async (e) => {
        e.preventDefault();
        const fd = new FormData(f);
        try {
          await api('profile', { method: 'POST', body: { username: fd.get('username'), gender: fd.get('gender') } });
          await boot();
        } catch (er) { toast(er.message); }
      },
    },
      h('div', {}, h('h1', {}, 'Tentang kamu'), h('p', { class: 'lead' }, S.character.name + ' ingin tahu siapa kamu.')),
      field('Nama pengguna', h('input', { name: 'username', required: '', maxlength: '30', autocomplete: 'off' })),
      h('div', { class: 'field' }, 'Jenis kelamin kamu', genderPicker('gender')),
      h('button', { class: 'btn', type: 'submit' }, 'Mulai ngobrol'));
    mount(h('main', { class: 'gate' }, f));
  }

  /* ---------- Aplikasi utama ---------- */
  let $body = null;

  function viewApp() {
    const tabBtn = (id, label) => h('button', { class: 'tab', 'data-tab': id, onclick: () => { tab = id; showTab(); } }, label);
    const head = h('header', { class: 'top' },
      h('div', { class: 'avatar', 'aria-hidden': 'true' }, S.character.name[0].toUpperCase()),
      h('div', { class: 'who' }, h('strong', {}, S.character.name), h('span', {}, S.character.traits)),
      h('button', { class: 'link', onclick: logout }, 'Keluar'));
    const nav = h('nav', { class: 'tabs' }, tabBtn('chat', 'Chat'), h('button', { class: 'tab', onclick: newChat }, 'Chat baru'), tabBtn('memory', 'Buku ingatan'));
    $body = h('section', { class: 'body' });
    mount(h('div', { class: 'shell' }, head, nav, $body));
    showTab();
  }

  function showTab() {
    document.querySelectorAll('[data-tab]').forEach((b) => b.setAttribute('aria-current', String(b.dataset.tab === tab)));
    $body.replaceChildren();
    if (tab === 'chat') viewChatTab(); else viewMemoryTab();
  }

  async function logout() {
    try { await api('logout', { method: 'POST' }); } catch (e) {}
    S = null; viewLogin();
  }

  async function newChat() {
    if (busy) return;
    if (!S.messages.length) { tab = 'chat'; showTab(); toast('Chat ini masih kosong.'); return; }
    try {
      const d = await api('chat/new', { method: 'POST' });
      S.chatId = d.chatId; S.messages = []; tab = 'chat'; showTab();
    } catch (e) { toast(e.message); }
  }

  /* ---------- Chat ---------- */
  function viewChatTab() {
    const list = h('div', { id: 'list', class: 'list', 'aria-live': 'polite' });
    const ta = h('textarea', { rows: '1', maxlength: '2000', placeholder: 'Tulis pesan untuk ' + S.character.name, 'aria-label': 'Pesan' });
    ta.value = draft;
    const send = () => {
      const t = ta.value.trim();
      if (!t) return;
      ta.value = ''; draft = ''; ta.style.height = 'auto';
      sendMessage(t, ta);
    };
    ta.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } });
    ta.addEventListener('input', () => { draft = ta.value; ta.style.height = 'auto'; ta.style.height = Math.min(ta.scrollHeight, 140) + 'px'; });
    $body.append(list, h('div', { class: 'composer' }, ta, h('button', { class: 'btn send', onclick: send }, 'Kirim')));
    renderList();
  }

  function lastBotId() {
    for (let i = S.messages.length - 1; i >= 0; i--) {
      const m = S.messages[i];
      if (m.role === 'assistant' && !m.pending) return m.id;
    }
    return null;
  }

  function msgNode(m, isLast) {
    if (m.role === 'user') return h('div', { class: 'msg me' }, m.content);
    if (m.pending) return h('div', { class: 'row' }, h('div', { class: 'msg' }, h('span', { class: 'dots', 'aria-label': 'Mengetik' }, h('i'), h('i'), h('i'))));
    const acts = h('div', { class: 'acts' }, h('button', { onclick: () => saveMemory(m) }, 'Tambah ingatan'));
    if (isLast) acts.append(h('button', { onclick: () => reload(m) }, 'Reload respons'));
    return h('div', { class: 'row' }, h('div', { class: 'msg' }, m.content), acts);
  }

  function renderList() {
    const list = document.getElementById('list');
    if (!list) return;
    if (!S.messages.length) {
      list.replaceChildren(h('p', { class: 'empty' }, 'Belum ada obrolan. Sapa ' + S.character.name + ' untuk mulai.'));
      return;
    }
    const last = lastBotId();
    list.replaceChildren(...S.messages.map((m) => msgNode(m, m.id === last)));
    list.scrollTop = list.scrollHeight;
  }

  async function sendMessage(text, ta) {
    if (busy) { draft = text; if (ta) ta.value = text; return; }
    busy = true;
    const mine = { id: 'tmp', role: 'user', content: text };
    S.messages.push(mine, { id: 'pending', role: 'assistant', content: '', pending: true });
    renderList();
    try {
      const d = await api('chat', { method: 'POST', body: { message: text, chatId: S.chatId } });
      S.chatId = d.chatId; mine.id = d.userId;
      S.messages.pop();
      S.messages.push({ id: d.reply.id, role: 'assistant', content: d.reply.content });
    } catch (e) {
      S.messages.pop(); S.messages.pop();
      draft = text;
      const box = document.querySelector('.composer textarea');
      if (box) box.value = text;
      toast(e.message);
    }
    busy = false;
    renderList();
  }

  async function reload(m) {
    if (busy) return;
    busy = true;
    const old = m.content;
    m.pending = true; renderList();
    try {
      const d = await api('chat/reload', { method: 'POST', body: { messageId: m.id } });
      m.content = d.content;
    } catch (e) { m.content = old; toast(e.message); }
    m.pending = false; busy = false; renderList();
  }

  async function addMemory(text) {
    const d = await api('memories', { method: 'POST', body: { content: text } });
    S.memories.unshift(d.memory);
  }

  async function saveMemory(m) {
    const text = window.prompt('Simpan ke buku ingatan (boleh diedit):', m.content.slice(0, 500));
    if (text == null || !text.trim()) return;
    try { await addMemory(text.trim()); toast('Tersimpan di buku ingatan.'); }
    catch (e) { toast(e.message); }
  }

  /* ---------- Buku ingatan ---------- */
  function viewMemoryTab() {
    const input = h('input', { maxlength: '500', placeholder: 'Hal yang perlu diingat ' + S.character.name, 'aria-label': 'Ingatan baru' });
    const form = h('form', {
      class: 'addmem',
      onsubmit: async (e) => {
        e.preventDefault();
        const t = input.value.trim();
        if (!t) return;
        try { await addMemory(t); input.value = ''; renderMemories(); }
        catch (er) { toast(er.message); }
      },
    }, input, h('button', { class: 'btn', type: 'submit' }, 'Tambah ingatan'));
    $body.append(h('div', { class: 'pane' },
      h('h2', {}, 'Buku ingatan'),
      h('p', { class: 'lead' }, S.character.name + ' akan selalu mengingat isi buku ini saat ngobrol.'),
      form, h('ul', { id: 'mems', class: 'mems' })));
    renderMemories();
  }

  function renderMemories() {
    const ul = document.getElementById('mems');
    if (!ul) return;
    if (!S.memories.length) { ul.replaceChildren(h('li', {}, 'Belum ada ingatan.')); return; }
    ul.replaceChildren(...S.memories.map((m) => h('li', {},
      h('span', {}, m.content),
      h('button', {
        class: 'link', 'aria-label': 'Hapus ingatan',
        onclick: async () => {
          try { await api('memories/' + m.id, { method: 'DELETE' }); S.memories = S.memories.filter((x) => x.id !== m.id); renderMemories(); }
          catch (e) { toast(e.message); }
        },
      }, 'Hapus'))));
  }

  boot();
})();
