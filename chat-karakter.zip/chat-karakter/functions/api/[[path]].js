// Semua endpoint API ada di sini. Rute: /api/<path>
const MODEL = '@cf/meta/llama-3-8b-instruct';
const GENDERS = ['perempuan', 'laki-laki', 'lainnya'];
const SESSION_MS = 30 * 24 * 3600 * 1000;

const json = (data, status = 200, headers = {}) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { 'content-type': 'application/json; charset=utf-8', ...headers },
  });
const fail = (msg, status = 400) => json({ error: msg }, status);
const clip = (s, n) => String(s ?? '').trim().slice(0, n);

function getCookie(req, name) {
  const m = (req.headers.get('cookie') || '').match(new RegExp('(?:^|; )' + name + '=([^;]*)'));
  return m ? m[1] : null;
}

async function currentUser(req, env) {
  const sid = getCookie(req, 'sid');
  if (!sid) return null;
  return env.DB.prepare(
    'SELECT u.* FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.id = ? AND s.expires > ?'
  ).bind(sid, Date.now()).first();
}

async function getCharacter(env, userId) {
  return env.DB.prepare('SELECT * FROM characters WHERE user_id = ? ORDER BY id LIMIT 1').bind(userId).first();
}

async function getState(env, user) {
  const character = await getCharacter(env, user.id);
  const chat = await env.DB.prepare('SELECT id FROM chats WHERE user_id = ? ORDER BY id DESC LIMIT 1').bind(user.id).first();
  const messages = chat
    ? (await env.DB.prepare('SELECT id, role, content FROM messages WHERE chat_id = ? ORDER BY id').bind(chat.id).all()).results
    : [];
  const memories = (await env.DB.prepare('SELECT id, content FROM memories WHERE user_id = ? ORDER BY id DESC').bind(user.id).all()).results;
  return {
    user: { name: user.name, username: user.username, gender: user.user_gender },
    character: character ? { name: character.name, gender: character.gender, traits: character.traits } : null,
    chatId: chat ? chat.id : null,
    messages,
    memories,
  };
}

async function generate(env, user, history) {
  const c = await getCharacter(env, user.id);
  const memories = (await env.DB.prepare('SELECT content FROM memories WHERE user_id = ? ORDER BY id DESC LIMIT 50').bind(user.id).all()).results;
  const mem = memories.length
    ? '\n\nIngatan penting tentang pengguna (pakai secara alami, jangan dibacakan satu per satu):\n' + memories.map((m) => '- ' + m.content).join('\n')
    : '';
  const system =
    `Kamu adalah ${c.name}, karakter berjenis kelamin ${c.gender}. Sifat dan kesukaanmu: ${c.traits}.\n` +
    `Kamu sedang mengobrol dengan ${user.username} (${user.user_gender}). ` +
    `Tetap dalam karakter dan jangan menyebut dirimu AI atau model bahasa. ` +
    `Balas dalam bahasa Indonesia yang santai, 1 sampai 4 kalimat, tanpa daftar.` + mem;
  const out = await env.AI.run(MODEL, {
    messages: [{ role: 'system', content: system }, ...history.slice(-20)],
    max_tokens: 300,
  });
  return clip(out.response, 2000) || '...';
}

async function readBody(req) {
  try { return await req.json(); } catch { return {}; }
}

export async function onRequest({ request, env }) {
  const url = new URL(request.url);
  const path = url.pathname.replace(/^\/api\/?/, '').split('/').filter(Boolean);
  const route = request.method + ' ' + path.join('/');

  try {
    if (route === 'GET config') return json({ clientId: env.GOOGLE_CLIENT_ID });

    if (route === 'POST login') {
      const { credential } = await readBody(request);
      if (!credential) return fail('Token Google tidak ada.');
      const r = await fetch('https://oauth2.googleapis.com/tokeninfo?id_token=' + encodeURIComponent(credential));
      if (!r.ok) return fail('Login Google gagal.', 401);
      const t = await r.json();
      if (t.aud !== env.GOOGLE_CLIENT_ID || String(t.email_verified) !== 'true') return fail('Login Google ditolak.', 401);
      await env.DB.prepare(
        'INSERT INTO users (google_sub, email, name, created_at) VALUES (?, ?, ?, ?) ' +
        'ON CONFLICT(google_sub) DO UPDATE SET email = excluded.email, name = excluded.name'
      ).bind(t.sub, t.email, t.name || '', Date.now()).run();
      const u = await env.DB.prepare('SELECT id FROM users WHERE google_sub = ?').bind(t.sub).first();
      const sid = crypto.randomUUID() + crypto.randomUUID();
      await env.DB.prepare('INSERT INTO sessions (id, user_id, expires) VALUES (?, ?, ?)').bind(sid, u.id, Date.now() + SESSION_MS).run();
      return json({ ok: true }, 200, {
        'set-cookie': `sid=${sid}; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=${SESSION_MS / 1000}`,
      });
    }

    const user = await currentUser(request, env);
    if (!user) return fail('Belum masuk.', 401);

    if (route === 'POST logout') {
      await env.DB.prepare('DELETE FROM sessions WHERE id = ?').bind(getCookie(request, 'sid')).run();
      return json({ ok: true }, 200, { 'set-cookie': 'sid=; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=0' });
    }

    if (route === 'GET state') return json(await getState(env, user));

    if (route === 'POST character') {
      const b = await readBody(request);
      const name = clip(b.name, 40), traits = clip(b.traits, 300);
      if (!name || !traits || !GENDERS.includes(b.gender)) return fail('Lengkapi nama, jenis kelamin, dan karakter yang kamu suka.');
      const existing = await getCharacter(env, user.id);
      if (existing) await env.DB.prepare('UPDATE characters SET name = ?, gender = ?, traits = ? WHERE id = ?').bind(name, b.gender, traits, existing.id).run();
      else await env.DB.prepare('INSERT INTO characters (user_id, name, gender, traits) VALUES (?, ?, ?, ?)').bind(user.id, name, b.gender, traits).run();
      return json({ ok: true });
    }

    if (route === 'POST profile') {
      const b = await readBody(request);
      const username = clip(b.username, 30);
      if (!username || !GENDERS.includes(b.gender)) return fail('Lengkapi nama pengguna dan jenis kelamin.');
      await env.DB.prepare('UPDATE users SET username = ?, user_gender = ? WHERE id = ?').bind(username, b.gender, user.id).run();
      return json({ ok: true });
    }

    if (route === 'POST chat/new') {
      const c = await getCharacter(env, user.id);
      if (!c) return fail('Buat karakter dulu.');
      const r = await env.DB.prepare('INSERT INTO chats (user_id, character_id, created_at) VALUES (?, ?, ?)').bind(user.id, c.id, Date.now()).run();
      return json({ chatId: r.meta.last_row_id });
    }

    if (route === 'POST chat') {
      const b = await readBody(request);
      const text = clip(b.message, 2000);
      if (!text) return fail('Pesan kosong.');
      const c = await getCharacter(env, user.id);
      if (!c || !user.username) return fail('Lengkapi karakter dan profil dulu.');
      let chatId = Number(b.chatId) || null;
      if (chatId) {
        const own = await env.DB.prepare('SELECT id FROM chats WHERE id = ? AND user_id = ?').bind(chatId, user.id).first();
        if (!own) chatId = null;
      }
      if (!chatId) {
        const r = await env.DB.prepare('INSERT INTO chats (user_id, character_id, created_at) VALUES (?, ?, ?)').bind(user.id, c.id, Date.now()).run();
        chatId = r.meta.last_row_id;
      }
      const ins = await env.DB.prepare('INSERT INTO messages (chat_id, role, content, created_at) VALUES (?, ?, ?, ?)').bind(chatId, 'user', text, Date.now()).run();
      const userId = ins.meta.last_row_id;
      const history = (await env.DB.prepare('SELECT role, content FROM messages WHERE chat_id = ? ORDER BY id').bind(chatId).all()).results;
      let reply;
      try {
        reply = await generate(env, user, history);
      } catch (e) {
        await env.DB.prepare('DELETE FROM messages WHERE id = ?').bind(userId).run();
        return fail('AI gagal membalas. Kuota harian mungkin habis, coba lagi nanti.', 502);
      }
      const rep = await env.DB.prepare('INSERT INTO messages (chat_id, role, content, created_at) VALUES (?, ?, ?, ?)').bind(chatId, 'assistant', reply, Date.now()).run();
      return json({ chatId, userId, reply: { id: rep.meta.last_row_id, content: reply } });
    }

    if (route === 'POST chat/reload') {
      const { messageId } = await readBody(request);
      const m = await env.DB.prepare(
        'SELECT m.id, m.chat_id, m.role FROM messages m JOIN chats c ON c.id = m.chat_id WHERE m.id = ? AND c.user_id = ?'
      ).bind(Number(messageId), user.id).first();
      if (!m || m.role !== 'assistant') return fail('Pesan tidak ditemukan.', 404);
      const last = await env.DB.prepare('SELECT MAX(id) AS id FROM messages WHERE chat_id = ?').bind(m.chat_id).first();
      if (last.id !== m.id) return fail('Hanya balasan terakhir yang bisa dimuat ulang.');
      const history = (await env.DB.prepare('SELECT role, content FROM messages WHERE chat_id = ? AND id < ? ORDER BY id').bind(m.chat_id, m.id).all()).results;
      let content;
      try {
        content = await generate(env, user, history);
      } catch (e) {
        return fail('AI gagal membalas. Kuota harian mungkin habis, coba lagi nanti.', 502);
      }
      await env.DB.prepare('UPDATE messages SET content = ? WHERE id = ?').bind(content, m.id).run();
      return json({ content });
    }

    if (route === 'POST memories') {
      const text = clip((await readBody(request)).content, 500);
      if (!text) return fail('Ingatan kosong.');
      const n = await env.DB.prepare('SELECT COUNT(*) AS n FROM memories WHERE user_id = ?').bind(user.id).first();
      if (n.n >= 50) return fail('Buku ingatan penuh (maksimal 50). Hapus beberapa dulu.');
      const r = await env.DB.prepare('INSERT INTO memories (user_id, content, created_at) VALUES (?, ?, ?)').bind(user.id, text, Date.now()).run();
      return json({ memory: { id: r.meta.last_row_id, content: text } });
    }

    if (request.method === 'DELETE' && path[0] === 'memories' && path[1]) {
      await env.DB.prepare('DELETE FROM memories WHERE id = ? AND user_id = ?').bind(Number(path[1]), user.id).run();
      return json({ ok: true });
    }

    return fail('Rute tidak ditemukan.', 404);
  } catch (e) {
    return fail('Terjadi kesalahan di server.', 500);
  }
}
